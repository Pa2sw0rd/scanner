﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
            //this.textBox1.Background = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0, 0));
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            //this.textBox1.BackColor= Color.FromArgb(70, this.textBox1.BackColor);
            //this.label5.BackColor= Color.FromArgb(70, this.label5.BackColor);
            this.label5.BackColor = Color.Transparent;
            //this.listView1.BackColor = Color.Transparent;//Color.FromArgb(70, this.textBox1.BackColor);
            this.Refresh();
        }

        private void main_Load(object sender, EventArgs e)
        {

        }



        public class TransTextBox : RichTextBox
        {
            [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
            static extern IntPtr LoadLibrary(string lpFileName);

            protected override CreateParams CreateParams
            {
                get
                {
                    CreateParams prams = base.CreateParams;
                    if (LoadLibrary("msftedit.dll") != IntPtr.Zero)
                    {
                        prams.ExStyle |= 0x020; // transparent 
                        prams.ClassName = "RICHEDIT50W";// TRANSTEXTBOXW
                    }
                    return prams;
                }
            }
        }

        private void transTextBox1_Enter(object sender, EventArgs e)
        {
            ///this.Refresh();
        }

        private void transTextBox1_TextChanged(object sender, EventArgs e)
        {
            //this.Refresh();
        }
    }
}
