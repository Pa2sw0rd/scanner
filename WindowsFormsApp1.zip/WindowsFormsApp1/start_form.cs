﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;

namespace WindowsFormsApp1
{
    public partial class start_form : Form
    {
        private float opacity = 0F;
        private float speed = 0.05F;
        
        public start_form()
        {
            InitializeComponent();
            this.Opacity = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (this.opacity == 1)
            {
                this.timer1.Enabled = false;

            }
            this.opacity += speed;
            this.Opacity = this.opacity;
        }

        private void start_form_MouseClick(object sender, MouseEventArgs e)
        {
            Form1 main_win = new Form1();
            main_win.Show();
            this.Hide();
        }
    }
}
